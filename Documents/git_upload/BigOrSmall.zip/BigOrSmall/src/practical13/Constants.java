package practical13;

public class Constants {
	private Constants() {}

	public static final int DRAW=0;
	public static final int WIN=1;
	public static final int LOSE=2;

	public static final int BIG=0;
	public static final int SMALL=1;
}

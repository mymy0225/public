INSERT IGNORE INTO category(id,name) VALUES(1,'衣類');
INSERT IGNORE INTO category(id,name) VALUES(2,'電化製品');
INSERT IGNORE INTO category(id,name) VALUES(3,'家具');
INSERT IGNORE INTO category(id,name) VALUES(4,'趣味');
INSERT IGNORE INTO category(id,name) VALUES(5,'雑貨');
INSERT IGNORE INTO category(id,name) VALUES(6,'その他');

